<?php

require_once 'core/App.php';
require_once 'core/Controller.php';
require_once 'core/Database.php';
require_once 'core/Flasher.php';
require_once 'config/config.php';

// Auto-load services
spl_autoload_register(function ($class) {
    $serviceFile = 'app/services/' . $class . '.php';
    if (file_exists($serviceFile)) {
        require_once $serviceFile;
    }
});
