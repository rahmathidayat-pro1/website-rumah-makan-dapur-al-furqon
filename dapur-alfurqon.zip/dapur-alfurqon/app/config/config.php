<?php

define('BASEURL', 'http://localhost/dapur-alfurqon');

// DB
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_dapur_alfurqon');

// Timezone
date_default_timezone_set('Asia/Jakarta');
